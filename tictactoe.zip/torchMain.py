import os
import constants
import numpy as np
import copy
import random
import torch
from collections import deque
import time
from tqdm import tqdm
from tictactoe import TicTacToeEnv
from torchAgent import Agent
from torch.utils.tensorboard import SummaryWriter
from visualizer import Visualizer

writer = SummaryWriter(flush_secs=5, log_dir = f'logs/{constants.MODEL_NAME}_{int(time.time())}') #log dosyasının oluşmasını sağlıyor



visualizer = Visualizer()
env = TicTacToeEnv()
visualizer.env = env
agent = Agent(env, (0,1), constants.LOAD_MODEL) #agent'ımızı oluşturuyor


#Loglayacağımız veriler
suma = 0
draw = 0
winX = 0
winO = 0
for episode in tqdm(range(1, constants.EPISODES + 1), ascii=True, unit='episodes'):

    env.start()
    xMoveHistory = []
    oMoveHistory = []

    done = False
    while not done:#oyun bitmediği sürece bu loop dönüyor
        
        toAppend = [copy.deepcopy(env.board)]#önce şuan ki durumumuzu kayıt ediyoruz.
        action = agent.makeMoveX(env.board) #yapılacak aksiyonun index'ini agent'dan alıyoruz.

        new_state, reward, done = env.move(action)#aksiyonun indexi'ini env'e vererek hareketi yapıyoruz ve oyunun yeni durumunu alıyoruz
        reward = -reward #X oyunu minimize etmeye çalışacağı için aldığı ödülü - olarak değiştiriyoruz.
        toAppend.append(action)
        toAppend.append(reward)
        xMoveHistory.append(toAppend)#agent'in yaptığı harekete karşı aldığı ödül'ler vs. eğitim için saklıyoruz

        

        if episode % constants.SHOW_EVERY == 0 and constants.IS_VISUALIZER_ON:#eğer görüntüleme açık ise oyunu her x oyunda bir görüntülüyoruz
            visualizer.show()


        ### Second Player ###
        if not done:
            toAppend=[copy.deepcopy(new_state)]

            action2 = agent.makeMoveO(new_state) 
            _, reward, done = env.move(action2)
            toAppend.append(action2)
            toAppend.append(reward)

            oMoveHistory.append(toAppend)
            ## ^ ilk agent ile aynı, tek farkı reward'ı -'ye çekmiyoruz

            if done:#eğer oyun bittiyse, yani O kazandıysa (beraberlik durumunu sadece X yapabiliyor)
                state, action, _, = xMoveHistory.pop() 
                xMoveHistory.append([state, action, reward])
                #x'in oynamış olduğu son aksiyonun değeri 0 değil +1 olmuş oluyor, çünkü x'in hamlesinden sonra yapılan hamle yani o'nun hamlesi
                #x'e göre enviroment'ın bir parçası. Çünkü x'in yaptığı hareketten sonra her hangi bir müdahale şansı olmadı, yani son yaptığı aksiyon
                #x'in kayıp etmesine sebep oldu, X'in son aksiyonu için eklemiş olduğumuz ödülü değiştirmemiz lazım, üstteki işlem bunu yapmaktadır.
                suma += -1
                winO += 1

        elif done and reward == 0:
            draw += 1 #eğer oyun bitti ve reward 0 ise draw demek

        else:
            #66 satırda anlatılan olayın aynısı, sadece O için
            state, action, _, = oMoveHistory.pop()
            oMoveHistory.append([state, action, reward])
            suma += 1
            winX +=1


        if episode % constants.SHOW_EVERY == 0 and constants.IS_VISUALIZER_ON:
            visualizer.show()

    agent.train(xMoveHistory, oMoveHistory)

    if not episode % constants.AGGREGATE_STATS_EVERY or episode == 1:

        writer.add_scalar('sum', suma, episode)
        writer.add_scalar('epsilon', constants.epsilon, episode)
        writer.add_scalar('draw', draw, episode)
        writer.add_scalar('winO', winO, episode)
        writer.add_scalar('winX', winX, episode)
        #Yukarıda tensorboard'umuza aldığımız verileri giriyouz.
        if not constants.IS_TEST:#eğer test değil ise, modelimizi kayıt ediyoruz
            torch.save(agent.model.state_dict(), f'models/{constants.MODEL_NAME}_{winX}_{int(time.time())}.model')
        draw = 0
        suma = 0
        winO = 0
        winX = 0
        #verileri 0'lıyoruz üst üste sürekli artan bir grafik görmeyelim

    # epsilon değerini ayarlıyoruz.
    if constants.epsilon > constants.MIN_EPSILON:
        constants.epsilon *= constants.EPSILON_DECAY
        constants.epsilon = max(constants.MIN_EPSILON, constants.epsilon)
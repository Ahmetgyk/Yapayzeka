import tensorflow as tf
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense, Dropout, Conv2D, MaxPooling2D, Activation, Flatten
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import TensorBoard
import numpy as np
import constants
import random
import time

class ModifiedTensorBoard(TensorBoard):


    # Overriding init to set initial step and writer (we want one log file for all .fit() calls)
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.step = 1
        self.writer = tf.summary.create_file_writer(self.log_dir)
        self._log_write_dir = self.log_dir


    # Overriding this method to stop creating default log writer
    def set_model(self, model):
        pass

    # Overrided, saves logs with our step number
    # (otherwise every .fit() will start writing from 0th step)
    def on_epoch_end(self, epoch, logs=None):
        self.update_stats(**logs)

    # Overrided
    # We train for one batch only, no need to save anything at epoch end
    def on_batch_end(self, batch, logs=None):
        pass

    # Overrided, so won't close writer
    def on_train_end(self, _):
        pass

    # Custom method for saving own metrics
    # Creates writer, writes custom metrics and closes writer
    def update_stats(self, **stats):
        self._write_logs(stats, self.step * int(constants.AGGREGATE_STATS_EVERY/5))

    def _write_logs(self, logs, index):
        with self.writer.as_default():
            for name, value in logs.items():
                tf.summary.scalar(name, value, step=index)
                self.step += 1
                self.writer.flush()


class Agent():

    def __init__(self, env, player, load=False, openBoard=False):
        self.player = player
        self.env = env

        if load:
            self.model = load_model(constants.MODEL_PATH)
            print('Model Loaded from', constants.MODEL_PATH)
            print('---------------------')
        
        else:        
            self.model = self.createModel()
        

        self.target_model = self.createModel()
        self.target_model.set_weights(self.model.get_weights())
        
        self.tensorboard = ModifiedTensorBoard(log_dir=f"logs/{constants.MODEL_NAME}-{int(time.time())}")
        self.target_update_counter = 0


    def createModel(self):
        model = Sequential()

        model.add(Flatten(input_shape=(3,3,2)))
        model.add(Dense(36))
        model.add(Activation("relu"))

        model.add(Dense(36))
        model.add(Activation("relu"))

        model.add(Dense(36))
        model.add(Activation("relu"))


        model.add(Dense(9, activation="tanh"))

        model.compile(loss="mse", optimizer=tf.keras.optimizers.SGD(learning_rate = constants.LR), metrics=['accuracy'])
        return model


    def get_qs(self, state, model):
        return self.model(np.array((state,)), training=False)[0].numpy().tolist()



    def makeMoveO(self, state):
        if np.random.random() > constants.epsilon:
            # Get action from Q table
            mask = self.env.getMask()
            q_values = []
            for q, maskValue in zip(self.get_qs(state, self.model), mask):
                if maskValue == 1:
                    q_values.append(q)
                else:
                    q_values.append(-999)
            action = np.argmax(q_values)


        else:
            legalMoves = self.env.getLegalMoves(self.env.board)
            actionList = []
            for move in legalMoves:
                actionList.append(constants.ACTION_LIST.index(move))
            action = random.choice(actionList)
        return action

    def makeMoveX(self, state):
        if np.random.random() > constants.epsilon:
            # Get action from Q table
            mask = self.env.getMask()
            q_values = []
            for q, maskValue in zip(self.get_qs(state, self.model), mask):
                if maskValue == 1:
                    q_values.append(q)
                else:
                    q_values.append(999)
            action = np.argmin(q_values)


        else:
            legalMoves = self.env.getLegalMoves(self.env.board)
            actionList = []
            for move in legalMoves:
                actionList.append(constants.ACTION_LIST.index(move))
            action = random.choice(actionList)
        return action

    def train(self, xMoveHistory, oMoveHistory):
        X=[]
        y=[]
        nextState, action, reward = oMoveHistory.pop()

        current_qs = self.get_qs(nextState, self.target_model)
        current_qs[action] = reward
        X.append(nextState)
        y.append(current_qs)

        for _ in range(len(oMoveHistory)):
            current_state, action, reward = oMoveHistory.pop()
            
            next_qs = self.get_qs(nextState, self.target_model)
            current_qs = self.get_qs(current_state, self.model)

            mask = self.env.getMask(nextState)
            qs_to_select = []
            for q, maskValue in zip(next_qs, mask):
                if maskValue == 1:
                    qs_to_select.append(q)

            next_q = max(qs_to_select)
            new_q  = reward + next_q * constants.DISCOUNT

            current_qs[action] = new_q
            X.append(current_state)
            y.append(current_qs)
            
            nextState = current_state   



        nextState, action, reward = xMoveHistory.pop()

        current_qs = self.get_qs(nextState, self.target_model)
        current_qs[action] = reward
        X.append(nextState)
        y.append(current_qs)


        for _ in range(len(xMoveHistory)):
            current_state, action, reward = xMoveHistory.pop()
            
            next_qs = self.get_qs(nextState, self.target_model)
            current_qs = self.get_qs(current_state, self.model)

            mask = self.env.getMask(nextState)
            qs_to_select = []
            for q, maskValue in zip(next_qs, mask):
                if maskValue == 1:
                    qs_to_select.append(q)

            next_q = max(qs_to_select)
            new_q  = reward + next_q * constants.DISCOUNT

            current_qs[action] = new_q
            X.append(current_state)
            y.append(current_qs)
            nextState = current_state
        
        self.model.fit(np.array(X), np.array(y), batch_size=1, verbose=0, shuffle=False)
        
        self.target_update_counter += 1
        if self.target_update_counter > constants.UPDATE_TARGET_EVERY:
            self.target_model.set_weights(self.model.get_weights())
            self.target_update_counter = 0
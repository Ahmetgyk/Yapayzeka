import os
import constants
import numpy as np
import copy
import random
import tensorflow as tf
from collections import deque
import time
from tqdm import tqdm
from tictactoe import TicTacToeEnv
from tfAgent import Agent
from visualizer import Visualizer



visualizer = Visualizer()
env = TicTacToeEnv()
visualizer.env = env
agent = Agent(env, (0,1), constants.LOAD_MODEL)


suma = 0
draw = 0
winX = 0
winO = 0
for episode in tqdm(range(1, constants.EPISODES + 1), ascii=True, unit='episodes'):
    
    current_state = copy.deepcopy(env.start())
    xMoveHistory = []
    oMoveHistory = []

    done = False
    while not done:
        
        toAppend = [copy.deepcopy(env.board)]
        action = agent.makeMoveX(env.board)

        new_state, reward, done = env.move(action)
        reward = -reward
        toAppend.append(action)
        toAppend.append(reward)
        xMoveHistory.append(toAppend)



        toAppend=[copy.deepcopy(new_state)]
        
        if episode % constants.SHOW_EVERY == 0 and constants.IS_VISUALIZER_ON:
            visualizer.show()

        ### Second Player ###

        if not done:

            action2 = agent.makeMoveO(new_state)
            _, reward, done = env.move(action2)
            toAppend.append(action2)
            toAppend.append(reward)

            oMoveHistory.append(toAppend)

            if done:
                state, action, _, = xMoveHistory.pop()
                xMoveHistory.append([state, action, reward])
                suma += -1
                winO += 1

        elif done and reward == 0:
            draw += 1

        else:
            state, action, _, = oMoveHistory.pop()
            oMoveHistory.append([state, action, reward])
            suma += 1
            winX +=1
        
        if episode % constants.SHOW_EVERY == 0 and constants.IS_VISUALIZER_ON:
            visualizer.show()

    agent.train(xMoveHistory, oMoveHistory)

    if not episode % constants.AGGREGATE_STATS_EVERY or episode == 1:
        agent.tensorboard.update_stats(sum=suma, epsilon=constants.epsilon, draw=draw, winO = winO, winX = winX)

        if not constants.IS_TEST:
            agent.model.save(f'models/{constants.MODEL_NAME}__{int(time.time())}.model')
        draw = 0
        suma = 0
        winO = 0
        winX = 0


    # Decay epsilon
    if constants.epsilon > constants.MIN_EPSILON:
        constants.epsilon *= constants.EPSILON_DECAY
        constants.epsilon = max(constants.MIN_EPSILON, constants.epsilon)
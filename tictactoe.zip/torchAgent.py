import torch
from torch import nn
from torch.nn import MSELoss
import numpy as np
import constants
import random

class DDQN(nn.Module):
    def __init__(self):
        super().__init__()
        self.createModel()


    def createModel(self):
        self.layer1 = nn.Linear(9, 36) #9 input alan ve bunu 36 output olarak verececk bir linear(Dense) layer
        self.layer2 = nn.Linear(36, 36)#36 input 36 output veren bir layer
        self.layer3 = nn.Linear(36, 9)#36 input 9 output veren bir layer
        #burada daha layerların bağlantıları sağlanmış durumda değil, bunu forward fonksiyonunda yapacağız.


    def forward(self, state): #bu fonksiyonun ismini değiştirmeyin, çalışması için adının forward olması lazım
        x = self.layer1(state) #state, yani inputumuzu layer'1 e vereceğimizi söylüyoruz
        x = torch.relu(x)#layer 1'den aldığımız outputları relu aktivaston fonksiyonundan geçiriyoruz

        x = self.layer2(x)#aktivasyon fonksiyonundan çıkan verileri layer2'ye atıyoruz
        x = torch.relu(x)#layer 2'den çıkanları relu fonksiyonundan geçiriyoruz

        x = self.layer3(x)#relu'den çıkanları layer3'e atıyoruz
        x = torch.tanh(x)#son olarak layer'e ten çıkan 9 verimizi tanh fonksiyonundan geçiriyoruz. ve çıkan sonucu dönüyoruz

        return x


class Agent():

    def __init__(self, env, player, load=False):
        self.player = player
        self.env = env

        self.model = DDQN()#modeli oluşturuyoruz
        self.target_model = DDQN()#modelimiz için tahminler yaparken, modelin stabil kalması için ekstra bir tane daha oluşturuyoruz
        
        if load:#eğer önceden eğittiğimiz ve üzerine eğitime devam edeceğimiz bir model var ise, bunu yüklüyoruz
            self.model.load_state_dict(torch.load(constants.MODEL_PATH))

        self.target_model.load_state_dict(self.model.state_dict())#model oluşturulurken değerler rastgele atılıyor, target model ve modelimizin
        #aynı değerlere sahip olması için target modelin ağırlıklarını model ile eşitliyoruz.
        self.target_model = self.target_model.eval()

        self.optimizer = torch.optim.SGD(self.model.parameters(), lr=constants.LR) #optimizer olarak, scholastic gradient descent kullanıyoruz
        self.loss_function = MSELoss()#loss fonksiyonu olarak, mean square error kullanıyoruz.

        #loss fonksyionlar, optimizer'lar ve layer'lar hakkında ki seçeneklere ve nasıl çalıştıklarını
        #https://pytorch.org/docs/stable/nn.html adresinden bakabilirsiniz.

        self.target_update_counter = 0

    def backpropagate(self, state, move_index, target_value):#eğitim işlemini nasıl gerçekleştireceğimiz

        self.optimizer.zero_grad()
        output = self.model(self.convert_to_tensor(state))#önce modelimizin tahminini alıyoruz,
        target = output.clone().detach()

        target[move_index] = target_value # daha sonra yaptığımız harekete denk gelen q value'yi değiştiriyoruz.

        loss = self.loss_function(output, target)#ilk alınan çıktı, ve değiştirdiğimiz çıktı arasında loss hesaplanıyor
        loss.backward()
        self.optimizer.step()
        #bu loss'a göre optimizer hesaplama yapıp, gerekli ağırlıkları değiştiriyor.


    def get_qs(self, state, model):#verilen model ile, verilen oyun durumuna göre tahminleri veriyor
        inputs = self.convert_to_tensor(state)
        with torch.no_grad():
            outputs = model(inputs)
        return outputs

    def convert_to_tensor(self, state):#oyun durumunu yapay zekaya vermek için hazırlıyor
        toTensor =[]
        for row in state:
            for square in row:
                if square == (0,0):
                    toTensor.append(0)
                elif square == (0,1):
                    toTensor.append(1)
                else:
                    toTensor.append(-1)
        return torch.tensor(toTensor, dtype=torch.float)

    def makeMoveO(self, state):#O için hamle yapıyor
        if np.random.random() > constants.epsilon:#burada epsilon ile rastgele seçilen 0-1 arasında ki bir sayı karşılaştırılacak
        #yapılacak hamlenin rastgele mi yoksa model tarafından mı yapılacağını belirliyoruz


            mask = self.env.getMask() #illegel hamleleri maskelemek için maske'yi env'den alıyoruz.
            q_values = []
            for q, maskValue in zip(self.get_qs(state, self.model), mask):
                if maskValue == 1:#eğer maskeni değeri 1 ise, yani hamle legal bir hamle ise 
                    q_values.append(q) #q valuesini doğrudan listeye ekliyoruz
                else:# eğer illegal bir hamle ise
                    q_values.append(-999)#-999 ekliyoruzki, maximum hamleyi seçerken illegal bir hamle seçmeyelim
            action = np.argmax(q_values)#maximum hamlenin index'ini seçiyoruz.


        else:#eğer rastgele bir hamle yapılacak ise
            legalMoves = self.env.getLegalMoves(self.env.board)#env'den legal olan tüm hamleler seçiliyor
            actionList = []
            for move in legalMoves:
                actionList.append(constants.ACTION_LIST.index(move))#indexlerini alıyoruz
            action = random.choice(actionList)#indexleri arasından rastgele bir hamle seçiyoruz.
        return action

    def makeMoveX(self, state):#O dan tek farkı, 999 eklemek ve minimumu seçmek
    	#O oyun durumunu maximuma çekmeye çalışırken, X minimuma çekmeye çalışıyor.
        if np.random.random() > constants.epsilon:
            mask = self.env.getMask()
            q_values = []
            for q, maskValue in zip(self.get_qs(state, self.model), mask):
                if maskValue == 1:
                    q_values.append(q)
                else:
                    q_values.append(999)
            action = np.argmin(q_values)


        else:
            legalMoves = self.env.getLegalMoves(self.env.board)
            actionList = []
            for move in legalMoves:
                actionList.append(constants.ACTION_LIST.index(move))
            action = random.choice(actionList)
        return action

    def train(self, xMoveHistory, oMoveHistory):#eğitim işleminin gerçekleştiği yer

        nextState, action, reward = oMoveHistory.pop()#pop'u kullanarak en son yapılan hamleyi alıyoruz.
        
        self.backpropagate(nextState, action, reward)#en son hamlede ki ödül, son durum olduğundan kaynaklı
        #bu veriyi direk eğitiyoruz.

        for _ in range(len(oMoveHistory)):#O nun yaptığı tüm hamleler için eğitim yapacağız
            current_state, action, reward = oMoveHistory.pop()#hangi durumda, hangi aksiyonu aldığı ve buna karşılık aldığı ödülü alıyoruz.
            
            next_qs = self.get_qs(nextState, self.target_model)#yaptığı hamleden sonra ki yapabileceği hamlelerin q değer'lerini alıyoruz.
            
            mask = self.env.getMask(nextState)#en iyi q değerini bulmadan önce, yapamayacağı, yani illegal hamleleri çıkartıyoruz.
            qs_to_select = []
            for q, maskValue in zip(next_qs, mask):
                if maskValue == 1:
                    qs_to_select.append(q.item())

            next_q = max(qs_to_select)#legal hamleler arasından maximum q değerini seçiyoruz
            new_q  = reward + next_q * constants.DISCOUNT#yapmış olduğu aksiyonu, bu aksiyondan aldığı ödül, + sonra ki aksiyonlardan 
            #alacağı ödül şeklinde ayarlıyoruz. böylece modelimizin ileri görüşlülüğü oluyor. discount parametresini
            #değiştirerek sonraki hamleleri ne kadar önemsemesi gerektiğini ayarlıyoruz.

            self.backpropagate(current_state, action, new_q)#yeni hesapladığımız q ile eğitim gerçekleştiriyoruz.

            nextState = current_state

        #Aynı işlemleri X için yapıyoruz,
        #maximumu almak yerine minimumu alıyoruz.
        nextState, action, reward = xMoveHistory.pop()
        self.backpropagate(nextState, action, reward)
        for _ in range(len(xMoveHistory)):
            current_state, action, reward = xMoveHistory.pop()
            
            next_qs = self.get_qs(nextState, self.target_model)
            mask = self.env.getMask(nextState)
            qs_to_select = []
            for q, maskValue in zip(next_qs, mask):
                if maskValue == 1:
                    qs_to_select.append(q.item())

            next_q = min(qs_to_select)
            new_q  = reward + next_q * constants.DISCOUNT

            self.backpropagate(current_state, action, new_q)

            nextState = current_state

        self.target_update_counter += 1
        if self.target_update_counter > constants.UPDATE_TARGET_EVERY:
            self.target_model.load_state_dict(self.model.state_dict())
            self.target_update_counter = 0

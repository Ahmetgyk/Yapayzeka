import os
import importlib

teams = {i:"" for i in os.listdir() if os.path.isdir(i)}

try:
    del teams["__pycache__"]
except:
    pass

for team in teams:
    files = os.listdir(team) 
    for file in files:
        if 'agent' in file.lower():
            filepath = f'{team}/{file}'.replace(".py", "").replace("/", ".")
            if not os.path.isdir(filepath):
                teams[team] = filepath
                
from sos import SosEnv

env = SosEnv()
player1 = __import__(teams['takimadi4']).takimadi4agent.Agent(env, 1)
player2 = __import__(teams['takimadi2']).takimadi2agent.Agent(env, 2)


env.start()

p1InGameScore = 0
p2InGameScore = 0

done = False
while not done:

    while not done:
        gameEnd = env.getLegalMoves(env.board).count(1)
        if gameEnd == 0:
            done = True
            break 

        scored = False

        action = player1.makeMove()
        env.move(action[0], action[1])


        score = env.score[1]
        if p1InGameScore != score:
            scored = True
            p1InGameScore = score

        if not scored:
            break


    while not done:
        gameEnd = env.getLegalMoves(env.board).count(1)
        if gameEnd == 0:
            done = True
            break 

        scored = False

        action = player2.makeMove()
        env.move(action[0], action[1])


        score = env.score[2]
        if p2InGameScore != score:
            scored = True
            p2InGameScore = score

        if not scored:
            break

print(env.score)
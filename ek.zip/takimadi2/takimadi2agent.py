import os
import sys
path = os.path.realpath(__file__).rsplit("/",1)[0]
sys.path.insert(1, path)

import takimadi2constants as constants
import random

class Agent:

    def __init__(self, env, player, load=False):
        self.env = env
        self.player = player


    def makeMove(self):
        legalMoves = self.env.getLegalMoves(self.env.board)        
        legalMoves = [i for i in range(len(legalMoves)) if legalMoves[i] == 1]

        action = random.choice(legalMoves)
        piece = random.choice([1,-1])
        if piece == 1:
            action += 36

        return constants.ACTION_SPACE[action]
